# FAQ's

## How do I uninstall LinUtil?
* You do not have to uninstall LinUtil. As it is a script you run from your terminal it only loads into your RAM. This means as soon as you close LinUtil it will be deleted off your system.