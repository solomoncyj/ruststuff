![maintenance: passively maintained](https://img.shields.io/badge/maintenance-passively--maintained-yellowgreen.svg)

# errno-sys

Raw FFI bindings to `errno` location.

Inspired by [`errno-dragonfly`](https://crates.io/crates/errno-dragonfly).
