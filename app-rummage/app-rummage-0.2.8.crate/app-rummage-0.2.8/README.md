# App Rummage

A small utility library to find installed and running applications for Linux using cgroups and
process matching

